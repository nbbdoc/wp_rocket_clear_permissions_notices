# WP Rocket | Clear Permissions Notices 

Hides notices for write permission issues with .htaccess and advanced-cache.php


To be used with:
* Hiding write permissions notices for .htaccess and advanced-cache.php


Last tested with:
* WP Rocket {3.2.x}
* WordPress {5.0.x}
